# -*- coding: utf-8 -*-
import json, time, secrets, string
import urllib.request, urllib.error, urllib.parse

KALT = "https://3206.frp1.ott.kaltura.com/api_v3/service"
API_VER, PARTNER_ID, LANG = "5.4.0", 3206, "slk"
UA = "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"

# Keycloak O2 - prihlasenie kodom zariadenia (ako v TV aplikaciach)
KC = "https://identity.o2.sk/realms/o2/protocol/openid-connect"
KC_CLIENT = "o2-xtv-kaltura"
DEVICE_GRANT = "urn:ietf:params:oauth:grant-type:device_code"


# Bez brandId odmietne householddevice/add novy udid s 1002 "Device type not
# allowed". 22 = rodina 5 (PC/MAC), ktoru maju vsetky uz registrovane
# zariadenia domacnosti a ktorej zodpoveda aj clientTag "...-PC".
BRAND_ID = 22
# o kolko IPTV Simple posuva zaciatok archivu pred program
# (pvr.iptvsimple catchupWatchEpgBeginBufferMins, predvolene 5 min)
BEGIN_BUFFER = 5 * 60


class O2Error(Exception):
    """Chyba Kaltury. code drzi cislo chyby, aby sa dalo rozlisit 500017."""

    def __init__(self, msg, code=""):
        Exception.__init__(self, msg)
        self.code = str(code or "")


# zrozumitelne hlasky k chybam, na ktore sa da narazit bezne
ERR_TEXT = {
    "500017": "Relácia vypršala alebo ju prevzalo iné zariadenie (500017). "
              "Treba nové prihlásenie.",
    "500016": "Reláciu zrušilo iné zariadenie alebo web o2tv.sk (500016).",
    "1015": "Zariadenie je už registrované (1015).",
    # O2 vyda pouzitelny token len pri prihlaseni cislom sluzby (SMS kod);
    # token z prihlasenia e-mailom a heslom vyzera rovnako, ale nema claim
    # authenticated_via_subscriber_id a Kaltura ho odmietne prave takto
    "2026": "O2 token neprijalo (2026). Pri prihlásení treba použiť číslo "
            "služby a SMS kód, nie e-mail a heslo.",
}


def err_info(err):
    """Z Kaltura chyby spravi (text, kod)."""
    code = str(err.get("code", "")) if isinstance(err, dict) else ""
    return ERR_TEXT.get(code, str(err)), code


def gen_udid():
    return "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(16))


class O2API:
    def __init__(self, store, state_dir=None, log=None):
        # store = Kodi nastavenia (statické: udid, client_tag, kvalita)
        # state = vlastný JSON súbor (meniace sa: ks, expiry, refresh token)
        self.s = store
        self.state_dir = state_dir
        self._state = None
        self._log = log
        self.write_error = ""    # posledne zlyhanie zapisu stavu
        self._hold_until = 0     # do kedy neskusat znova zlyhanu obnovu

    # ---------- stav mimo nastavení ----------
    def _state_path(self):
        import os
        return os.path.join(self.state_dir or ".", "session.json")

    def st_load(self, force=False):
        # vždy čítaj z disku - addon.py a service.py bežia ako dva procesy
        if force or self._state is None:
            try:
                with open(self._state_path()) as f:
                    self._state = json.load(f)
            except Exception:
                self._state = {}
        return self._state

    def st_get(self, key, default=""):
        return self.st_load(force=True).get(key, default)

    def st_set(self, **kw):
        import os, tempfile
        st = self.st_load(force=True)   # zlúč s tým, čo je práve na disku
        st.update(kw)
        self._state = st
        d = self.state_dir or "."
        try:
            os.makedirs(d, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=d)
            with os.fdopen(fd, "w") as f:
                json.dump(st, f)
            os.replace(tmp, self._state_path())
            self.write_error = ""
        except Exception as e:
            # tichy pad tu znamena, ze sa neulozi obnoveny refresh token
            # a relacia po case zomrie na 500017 - musi byt vidiet
            self.write_error = str(e)
            if self._log:
                self._log("zápis %s zlyhal: %s" % (self._state_path(), e))

    def state_writable(self):
        """Skusobny zapis rovnakou cestou ako st_set (mkstemp + os.replace).
        Ked stav nejde ulozit, obnovena relacia sa nikam neulozi a po
        vyprsani KS zomrie aj refresh token. Vracia (ok, detail)."""
        import os, tempfile
        d = self.state_dir or "."
        probe = os.path.join(d, "session.probe")
        try:
            os.makedirs(d, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=d)
            with os.fdopen(fd, "w") as f:
                f.write("probe")
            os.replace(tmp, probe)
            os.remove(probe)
            return True, ""
        except Exception as e:
            try:
                os.remove(probe)
            except Exception:
                pass
            return False, str(e)

    # ---------- HTTP ----------
    def _post(self, url, body, raw=None, ctype=None):
        data = raw if raw is not None else json.dumps(body).encode("utf-8")
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("content-type", ctype or "application/json;charset=UTF-8")
        req.add_header("accept", "*/*")
        req.add_header("user-agent", UA)
        try:
            with urllib.request.urlopen(req, timeout=12) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            raise O2Error("HTTP %s: %s" % (e.code, e.read()[:300]))
        except OSError as e:
            # URLError, timeout, odmietnute spojenie - bez prevodu by vypadok
            # siete obisiel vsetky "except O2Error" a zabil sluzbu
            raise O2Error("sieť: %s" % e, "NET")

    def _kalt(self, action, body, _retry=False):
        tag = self.s.get("client_tag")
        payload = {"clientTag": tag, "apiVersion": API_VER, "partnerId": PARTNER_ID}
        payload.update(body)
        url = "%s/%s?format=1&clientTag=%s" % (KALT, action, tag)
        try:
            res = json.loads(self._post(url, payload).decode("utf-8"))
        except ValueError as e:
            raise O2Error("neplatná odpoveď Kaltury: %s" % e, "BADJSON")
        result = res.get("result", res)
        if isinstance(result, dict) and result.get("error"):
            if ("500016" in str(result["error"]) and not _retry
                    and "ottuser/action" not in action):
                self.st_set(ks_expiry=0)
                self.refresh()
                if "ks" in body:
                    body = dict(body, ks=self.ks())
                return self._kalt(action, body, True)
            raise O2Error(*err_info(result["error"]))
        return result

    # ---------- session ----------
    # relácia sa obnovuje raz denne, nie až pred vypršaním:
    # Kaltura zneplatní refresh token spolu s KS, takže čakanie na
    # koniec platnosti znamená stratu prihlásenia
    MAX_AGE = 86400

    def state_age(self):
        """Ako dlho (v sekundach) je ulozeny stav stary, -1 ked stav chyba.
        Ked je vyssi nez MAX_AGE, denna obnova neprechadza - ks() to
        maskuje fallbackom na staru KS, takze inak by to nebolo vidiet."""
        try:
            got = int(self.st_get("ks_issued") or 0)
        except Exception:
            got = 0
        return int(time.time()) - got if got else -1

    # Refresh token je viazany na KS z prihlasenia, nie na tu poslednu
    # obnovenu: po ~7 dnoch vrati 500017 aj zariadenie, ktore sa poctivo
    # obnovovalo kazdy den (merane 13. 9. 2026 na PC aj telke naraz).
    # ks_expiry sa kazdou obnovou posuva, takze odpocet sa musi ratat
    # od prihlasenia - inak by ukazoval stale 7 dni.
    LOGIN_TTL = 7 * 86400

    def session_left(self):
        """Kolko sekund zostava do nutneho noveho prihlasenia.
        Vracia (sekundy, je_to_len_odhad); (-1, False) ked stav chyba."""
        now = int(time.time())
        try:
            lt = int(self.st_get("login_time") or 0)
        except Exception:
            lt = 0
        if lt:
            return lt + self.LOGIN_TTL - now, bool(self.st_get("login_time_est"))
        # Zariadenie prihlasene verziou, ktora login_time este nepisala.
        # Odhadneme ho z ks_expiry a zapiseme, nech dalsie kolo uz pocita
        # presne; prvy odhad je optimisticky o tolko, kolko uz relacia bezi.
        exp = self.ks_remaining()
        if exp < 0:
            return -1, False
        lt = now + exp - self.LOGIN_TTL
        try:
            self.st_set(login_time=lt, login_time_est=True)
        except Exception:
            pass
        return lt + self.LOGIN_TTL - now, True

    def ks_remaining(self):
        """Kolko sekund este plati ulozena KS, -1 ked nie je znama."""
        try:
            exp = int(self.st_get("ks_expiry") or 0)
        except Exception:
            exp = 0
        return exp - int(time.time()) if exp else -1

    def ks(self):
        now = int(time.time())
        try:
            exp = int(self.st_get("ks_expiry") or 0)
        except Exception:
            exp = 0
        try:
            got = int(self.st_get("ks_issued") or 0)
        except Exception:
            got = 0
        cur = self.st_get("ks")
        if cur and exp - now > 300 and (now - got < self.MAX_AGE
                                        or now < self._hold_until):
            return cur
        try:
            return self.refresh()
        except O2Error as e:
            if cur and exp - now > 300:
                # mrtvy refresh (500017) sa do hodiny nezmeni, vypadok siete
                # skor - bez pauzy skusal export EPG obnovu pri kazdom volani
                self._hold_until = now + (3600 if e.code == "500017" else 120)
                # stara KS este plati, takze doplnok hra dalej a vypadok
                # obnovy by inak nebolo v logu vidiet - az kym nie je neskoro
                if self._log:
                    self._log("obnova relácie zlyhala (%s), pokračujem so "
                              "starou KS, platí ešte %.1f dňa"
                              % (e, max(exp - now, 0) / 86400.0))
                return cur
            raise

    def refresh(self):
        # token zo stavu má prednosť; nastavenie je len počiatočný vklad
        rt = self.st_get("refresh_token") or self.s.get("refresh_token")
        udid = self.st_get("udid") or self.s.get("udid")
        if not rt or not udid:
            # vlastny kod, aby addon.py vedel ponuknut prihlasenie rovnako
            # ako pri 500017 - na novom zariadeni sa inak nema od coho odrazit
            raise O2Error("Zariadenie ešte nie je prihlásené.", "NOSESSION")
        cur = self.st_get("ks") or self.s.get("ks") or ""
        if not cur:
            cur = self._kalt("ottuser/action/anonymousLogin",
                             {"language": "*"})["ks"]
        res = self._kalt("ottuser/action/refreshSession", {
            "language": LANG, "ks": cur,
            "refreshToken": rt, "udid": udid,
        })
        ls = res.get("loginSession", res)
        self.st_set(ks=ls["ks"], ks_expiry=int(ls["expiry"]),
                    ks_issued=int(time.time()),
                    refresh_token=ls.get("refreshToken") or rt)
        return ls["ks"]

    # ---------- prihlásenie kódom zariadenia ----------
    # Keycloak O2 povoluje device flow, takze prihlasenie ide priamo z Kodi:
    # doplnok ukaze kod, uzivatel ho potvrdi v prehliadaci na inom zariadeni.
    def _kc(self, path, form):
        data = urllib.parse.urlencode(form).encode()
        req = urllib.request.Request(KC + path, data=data, method="POST")
        req.add_header("content-type", "application/x-www-form-urlencoded")
        req.add_header("user-agent", UA)
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                return json.loads(e.read().decode("utf-8"))
            except Exception:
                raise O2Error("identity.o2.sk vrátilo HTTP %s" % e.code)

    def device_start(self):
        """Zacne prihlasenie. Vracia dict s user_code, verification_uri_complete,
        device_code, interval a expires_in."""
        res = self._kc("/auth/device", {"client_id": KC_CLIENT, "scope": "openid"})
        if not res.get("device_code"):
            raise O2Error(res.get("error_description") or res.get("error")
                          or "O2 nevydalo kód zariadenia")
        return res

    def device_poll(self, device_code):
        """Access token, alebo None kym uzivatel kod nepotvrdil."""
        res = self._kc("/token", {"client_id": KC_CLIENT, "grant_type": DEVICE_GRANT,
                                  "device_code": device_code})
        if res.get("access_token"):
            return res["access_token"]
        err = res.get("error", "")
        if err in ("authorization_pending", "slow_down"):
            return None
        if err == "expired_token":
            raise O2Error("Kód vypršal, skús prihlásenie znova.")
        if err == "access_denied":
            raise O2Error("Prihlásenie bolo v prehliadači zamietnuté.")
        raise O2Error(res.get("error_description") or err or "neznáma chyba")

    def login_with_token(self, access_token):
        udid = self.st_get("udid") or self.s.get("udid") or gen_udid()
        anon = self._kalt("ottuser/action/anonymousLogin", {"language": "*"})
        res = self._kalt("ottuser/action/login", {
            "language": LANG, "ks": anon["ks"], "udid": udid,
            "username": "11111", "password": "11111",
            "extraParams": {
                "loginType": {"objectType": "KalturaStringValue", "value": "accessToken"},
                "accessToken": {"objectType": "KalturaStringValue", "value": access_token},
            },
        })
        ls = res["loginSession"]
        self.st_set(udid=udid)
        self.st_set(ks=ls["ks"], ks_expiry=int(ls["expiry"]),
                    ks_issued=int(time.time()),
                    login_time=int(time.time()), login_time_est=False,
                    refresh_token=ls.get("refreshToken") or "")
        # Prihlasenie samo zariadenie do domacnosti nezapise a bez toho
        # getPlaybackContext vracia 1003 "Device not in household" - kanaly
        # aj EPG pritom chodia, takze sa to prejavi az pri prehravani.
        self.register_device()
        return ls

    def register_device(self, name="Kodi"):
        """Zapise UDID do domacnosti. Uz registrovane zariadenie Kaltura
        odmietne vlastnou chybou, co nie je dovod padnut."""
        udid = self.st_get("udid") or self.s.get("udid")
        if not udid:
            return False
        try:
            self._kalt("householddevice/action/add", {
                "ks": self.ks(),
                "device": {"objectType": "KalturaHouseholdDevice",
                           "udid": udid, "name": name, "brandId": BRAND_ID},
            })
            if self._log:
                self._log("zariadenie zaregistrované do domácnosti")
            return True
        except O2Error as e:
            if self._log:
                self._log("registrácia zariadenia neprešla: %s" % e)
            return False

    # ---------- kanály ----------
    def channels(self):
        res = self._kalt("asset/action/list", {
            "ks": self.ks(), "language": LANG,
            "filter": {"objectType": "KalturaSearchAssetFilter",
                       "kSql": "(and asset_type='714')"},
            "pager": {"objectType": "KalturaFilterPager",
                      "pageIndex": 1, "pageSize": 500},
        })
        out = []
        for x in res.get("objects", []) or []:
            imgs = x.get("images") or []
            logo = None
            for im in imgs:
                if im.get("imageTypeId") == 18:
                    logo = im.get("url"); break
            if not logo and imgs:
                logo = imgs[0].get("url")
            if logo:
                logo = "%s/height/320/width/480" % logo
            num = ((x.get("metas") or {}).get("ChannelNumber") or {}).get("value")
            out.append({"id": str(x["id"]), "name": x.get("name", ""),
                        "number": num, "logo": logo})
        out.sort(key=lambda c: (c["number"] is None, c["number"]))
        return out

    # ---------- prehrávanie ----------
    def playback_context(self, asset_id, ref_type, asset_type, context, _retry=False):
        ks = self.ks()
        body = {"clientTag": self.s.get("client_tag"), "apiVersion": API_VER,
                "partnerId": PARTNER_ID, "ks": ks}
        body["1"] = {"service": "asset", "action": "get",
                     "assetReferenceType": ref_type, "id": asset_id, "ks": ks}
        body["2"] = {"service": "asset", "action": "getPlaybackContext",
                     "assetType": asset_type, "assetId": asset_id,
                     "contextDataParams": {
                         "objectType": "KalturaPlaybackContextOptions",
                         "context": context, "streamerType": "mpegdash",
                         "urlType": "DIRECT",
                         "adapterData": {"codec": {"value": "AVC"},
                                         "quality": {"value": "UHD"}}},
                     "ks": ks}
        url = "%s/multirequest" % KALT
        res = json.loads(self._post(url, body).decode("utf-8"))
        result = res.get("result", [])
        pc = result[1] if isinstance(result, list) and len(result) > 1 else result
        if isinstance(pc, dict) and pc.get("error"):
            if "500016" in str(pc["error"]) and not _retry:
                self.st_set(ks_expiry=0)
                self.refresh()
                return self.playback_context(asset_id, ref_type, asset_type,
                                             context, True)
            # 1003 = zariadenie nie je v domacnosti; sam sa zaregistruj a skus
            # este raz, nech sa to nemusi riesit novym prihlasenim
            if "1003" in str(pc["error"]) and not _retry \
                    and self.register_device():
                return self.playback_context(asset_id, ref_type, asset_type,
                                             context, True)
            raise O2Error(*err_info(pc["error"]))
        return pc

    @staticmethod
    def pick_source(pc):
        srcs = (pc or {}).get("sources", []) or []
        wv = next((s for s in srcs if str(s.get("type", "")).upper() == "DASH_WV"), None)
        dash = next((s for s in srcs if str(s.get("type", "")).upper().startswith("DASH")), None)
        return wv or dash or (srcs[0] if srcs else None)

    @staticmethod
    def widevine_url(pc):
        for d in (O2API.pick_source(pc) or {}).get("drm", []) or []:
            if "WIDEVINE" in str(d.get("scheme", "")).upper():
                return d.get("licenseURL")
        return None

    @staticmethod
    def not_entitled(pc):
        for m in (pc or {}).get("messages", []) or []:
            if str(m.get("code", "")).upper() == "NOTENTITLED":
                return True
        return False

    def resolve(self, cid, start_ts=None, end_ts=None):
        """Vráti (manifest_url, license_url)."""
        now = int(time.time())
        if start_ts and end_ts and int(start_ts) < now - 10:
            ctx = "CATCHUP" if int(end_ts) < now - 10 else "START_OVER"
            prog = self._find_programme(cid, int(start_ts), int(end_ts))
            self.last_mode = "%s cid=%s start=%s prog=%s" % (ctx, cid, start_ts, prog)
            pc = self.playback_context(prog, "epg_internal", "epg", ctx) if prog \
                else self.playback_context(cid, "media", "media", "PLAYBACK")
        else:
            self.last_mode = "LIVE cid=%s start=%s end=%s" % (cid, start_ts, end_ts)
            pc = self.playback_context(cid, "media", "media", "PLAYBACK")
        src = self.pick_source(pc)
        if not src:
            # Ked Kaltura zdroje nevrati, dovod pise do messages (NOTENTITLED,
            # limit subeznych streamov, neregistrovane zariadenie). Bez nich je
            # "Ziadny DASH zdroj" slepa hlaska, z ktorej sa neda nic zistit.
            msgs = [m for m in (pc or {}).get("messages", []) or []]
            detail = "; ".join(
                ("%s %s" % (m.get("code", ""), m.get("message", ""))).strip()
                for m in msgs) or "Kaltura neposlala ani dôvod."
            raise O2Error("Žiadny DASH zdroj: %s" % detail,
                          msgs[0].get("code", "") if msgs else "")
        return src.get("url"), self.widevine_url(pc)

    def _find_programme(self, cid, start_ts, end_ts=None):
        # IPTV Simple posúva začiatok o buffer dopredu (catchupWatchEpgBeginBufferMins,
        # 5 min) a koniec o 15 min dozadu - ale programu, ktorý ešte beží, dá
        # ako koniec "teraz mínus 5 min". Pri programe, ktorý začal pred menej
        # než 5 min, tak celý rozsah leží v predchádzajúcom programe a stred
        # rozsahu pustil ten (14. 10. 2026: Top Star pustil Noviny). Berieme
        # program so začiatkom najbližšie k start + buffer.
        want = start_ts + BEGIN_BUFFER
        end_ts = max(end_ts or start_ts, want)
        ksql = ("(and linear_media_id:'%s' start_date <= '%d' end_date > '%d' "
                "asset_type='epg' auto_fill=true)" % (cid, end_ts, start_ts))
        res = self._kalt("asset/action/list", {
            "ks": self.ks(), "language": LANG,
            "filter": {"objectType": "KalturaSearchAssetFilter",
                       "orderBy": "START_DATE_ASC", "kSql": ksql},
            "pager": {"objectType": "KalturaFilterPager",
                      "pageSize": 50, "pageIndex": 1},
        })
        objs = res.get("objects", []) or []
        if not objs:
            return None
        return min(objs, key=lambda o: abs(int(o.get("startDate", 0)) - want))["id"]

    # ---------- EPG ----------
    def epg_batch(self, channel_ids, start_ts, end_ts):
        ors = " ".join("linear_media_id:'%s'" % c for c in channel_ids)
        ksql = ("(and (or %s) start_date >= '%d' end_date <= '%d' "
                "asset_type='epg' auto_fill=true)" % (ors, start_ts, end_ts))
        out, page = [], 1
        while True:
            res = self._kalt("asset/action/list", {
                "ks": self.ks(), "language": LANG,
                "filter": {"objectType": "KalturaSearchAssetFilter",
                           "orderBy": "START_DATE_ASC", "kSql": ksql},
                "pager": {"objectType": "KalturaFilterPager",
                          "pageSize": 500, "pageIndex": page},
            })
            objs = res.get("objects", []) or []
            out += objs
            if not objs or len(out) >= int(res.get("totalCount", 0)) or page > 25:
                break
            page += 1
        return out

    # ---------- clientTag ----------
    def update_client_tag(self):
        """Stiahne aktuálny clientTag z o2tv.sk JS bundle."""
        import re
        req = urllib.request.Request("https://www.o2tv.sk/", headers={"user-agent": UA})
        with urllib.request.urlopen(req, timeout=20) as r:
            html = r.read().decode("utf-8", "ignore")
        for m in re.finditer(r'src="([^"]+\.js)"', html):
            src = m.group(1)
            if src.startswith("/"):
                src = "https://www.o2tv.sk" + src
            try:
                rq = urllib.request.Request(src, headers={"user-agent": UA})
                with urllib.request.urlopen(rq, timeout=20) as r2:
                    js = r2.read().decode("utf-8", "ignore")
            except Exception:
                continue
            t = re.search(r'clientTag["\']?\s*[:=]\s*["\']([\d.]+-[A-Za-z]+)["\']', js)
            if t:
                self.s.set("client_tag", t.group(1))
                return t.group(1)
        return None

    # ---------- filter predplatného ----------
    def entitled_ids(self, channel_ids, progress_cb=None):
        """Vráti množinu ID kanálov, ktoré máš v predplatnom.
        progress_cb(hotovo, celkom) sa volá priebežne (na zobrazenie postupu)."""
        ok = set()
        total = len(channel_ids)
        for i, cid in enumerate(channel_ids):
            try:
                pc = self.playback_context(cid, "media", "media", "PLAYBACK")
                if not self.not_entitled(pc):
                    ok.add(cid)
            except O2Error:
                ok.add(cid)      # pri chybe kanál radšej nechaj
            except Exception:
                ok.add(cid)
            if progress_cb:
                progress_cb(i + 1, total)
        # poistka zo sidecaru: podozrivo málo -> neprepisuj cache
        if total and not ok:
            return None
        return ok

    def entitled_cached(self, channel_ids, ttl=43200, progress_cb=None):
        """Filter s 12h cache v nastaveniach addonu."""
        now = int(time.time())
        try:
            ts_ = int(self.s.get("entitled_ts") or 0)
            cached = self.s.get("entitled_ids") or ""
        except Exception:
            ts_, cached = 0, ""
        if cached and now - ts_ < ttl:
            return set(cached.split(","))
        ok = self.entitled_ids(channel_ids, progress_cb)
        if ok is None:
            return set(channel_ids)   # dočasne nechaj všetky
        self.s.set("entitled_ids", ",".join(sorted(ok)))
        self.s.set("entitled_ts", str(now))
        return ok
