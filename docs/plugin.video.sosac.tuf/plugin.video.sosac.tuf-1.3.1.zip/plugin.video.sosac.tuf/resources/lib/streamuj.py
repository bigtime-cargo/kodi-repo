# -*- coding: utf-8 -*-
"""Získanie streamu zo streamuj.tv (prepis streamujtvresolver.py + probe_html5 zo Sosáča).

Pôvodný kód: Libor Zoubek + jondas, GPL-2.0-or-later.
"""

import datetime
import hashlib
import re
import urllib.parse

from resources.lib import net

VIDEO_URL = 'http://www.streamuj.tv/video/'
HOME_URL = 'https://www.streamuj.tv/'
LOGIN_URL = 'https://www.streamuj.tv/login'
PREMIUM_RE = re.compile(r'aktivn\S* do:\s*<strong>\s*(\d{1,2})\.(\d{1,2})\.(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})')
REFERER = 'http://www.streamuj.tv/mediaplayer/player.swf'

QUALITY_RANK = {'720p': 2, 'SD': 1}


class StreamujError(Exception):
    pass


def _find(name, html):
    m = re.search(name + r'\:[^"]*"([^"]+)', html, re.IGNORECASE | re.DOTALL)
    return m.group(1) if m else None


def streams(video_id):
    """Zoznam dostupných streamov: url, quality ('720p'/'SD'), lang, lang_name, subs."""
    status, body, _ = net.get(VIDEO_URL + video_id)
    html = body.decode('utf-8', 'replace')
    if status != 200 or 'Toto video neexistuje' in html:
        raise StreamujError('Video na streamuj.tv neexistuje')
    rn = (_find('rn', html) or '').split(',')
    langs = (_find('langs', html) or '').split(',')
    result = []
    for index, lang in enumerate(langs):
        res = _find('res%d' % index, html)
        if not res or not rn:
            continue
        code, _, lang_name = lang.partition('>')
        subs = _find('sub%d' % index, html)
        if subs:
            m = re.search(r'[^>]+>([^,$]+)', subs)
            subs = m.group(1) if m else None
        for qindex, url in enumerate(res.split(',')):
            q = rn[qindex] if qindex < len(rn) else 'SD'
            result.append({
                'url': url,
                'quality': '720p' if q == 'HD' else 'SD',
                'lang': code,
                'lang_name': lang_name or code,
                'subs': subs,
            })
    if not result:
        raise StreamujError('Na stránke streamuj.tv sa nenašiel žiadny stream')
    return result


def final_url(stream, user='', password='', location='0'):
    """Doplní prihlásenie, zistí skutočnú adresu videa a pridá hlavičky pre Kodi."""
    url = stream['url']
    if user and password:
        h = hashlib.md5(password.encode('utf-8')).hexdigest()
        url += '&pass=%s:::%s' % (user, hashlib.md5(h.encode('utf-8')).hexdigest())
    if location in ('1', '2'):
        url += '&location=%s' % location
    headers = {'User-Agent': net.UA, 'Referer': REFERER, 'Cookie': net.cookie_header()}
    status, body, resp_headers = net.get(url, headers=headers, follow=False)
    if status == 200:
        real = body.decode('utf-8', 'replace').strip()
    elif status in (301, 302, 303, 307) and resp_headers.get('Location'):
        real = resp_headers['Location']
    else:
        raise StreamujError('streamuj.tv vrátil HTTP %s' % status)
    if not real.startswith('http'):
        raise StreamujError('streamuj.tv nevrátil adresu videa: %s' % real[:120])
    return real + '|' + urllib.parse.urlencode(headers)


def download_subs(url, path):
    status, body, _ = net.get(url, headers={'Referer': REFERER})
    if status != 200 or not body:
        return False
    with open(path, 'wb') as f:
        f.write(body)
    return True


def premium_until(user, password):
    """Prihlási sa na streamuj.tv a vráti koniec premium (datetime), None ak účet premium nemá.

    API na to streamuj.tv nemá – dátum je len na úvodnej stránke po prihlásení:
    „Premium účet máte aktivní do: <strong>28.12.2026 21:43:58</strong>“.
    """
    form = urllib.parse.urlencode({'username': user, 'password': password,
                                   'action_login': 'Log In', 'login_remember': 'on'}).encode()
    status, body, _ = net.get(LOGIN_URL, data=form, headers={'Referer': LOGIN_URL})
    html = body.decode('utf-8', 'replace')
    if 'logout' not in html:
        status, body, _ = net.get(HOME_URL)
        html = body.decode('utf-8', 'replace')
    if 'logout' not in html:
        raise StreamujError('Prihlásenie na streamuj.tv zlyhalo – skontroluj meno a heslo')
    m = PREMIUM_RE.search(html)
    if not m:
        return None
    d, mo, y, h, mi, s = map(int, m.groups())
    return datetime.datetime(y, mo, d, h, mi, s)
