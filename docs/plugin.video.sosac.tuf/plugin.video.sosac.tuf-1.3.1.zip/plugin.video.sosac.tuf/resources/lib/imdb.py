# -*- coding: utf-8 -*-
"""Hodnotenia z IMDb: súbor title.ratings.tsv.gz z datasets.imdbws.com v SQLite (addon_data/imdb.db).

Súbor (~9 MB, 1,7 mil. titulov, IMDb ho obnovuje denne) sťahuje a spracúva doplnok raz za týždeň
po vykreslení zoznamu, zoznamy z databázy len čítajú. Dáta IMDb sú na osobné a nekomerčné použitie.
"""

import gzip
import io
import os
import sqlite3
import time

from resources.lib import net

URL = 'https://datasets.imdbws.com/title.ratings.tsv.gz'
DB = 'imdb.db'
MAX_AGE = 7 * 86400
# rozpracovaná databáza (.tmp) mladšia ako toto = práve ju stavia iné spustenie doplnku
BUILDING_TTL = 600


class Aborted(Exception):
    pass


class Imdb:
    def __init__(self, folder):
        path = os.path.join(folder, DB)
        self.db = None
        if os.path.exists(path):
            try:
                self.db = sqlite3.connect(path, timeout=10)
            except sqlite3.Error:
                pass

    def rating(self, imdb):
        """'tt0109830' → (8.8, 2412345) alebo None."""
        if not (self.db and imdb):
            return None
        try:
            row = self.db.execute('SELECT rating, votes FROM r WHERE id = ?', (int(imdb[2:]),)).fetchone()
        except (sqlite3.Error, ValueError):
            return None
        return (row[0] / 10.0, row[1]) if row else None


def age(folder):
    """Koľko sekúnd je databáza stará, None ak ešte nie je."""
    try:
        return time.time() - os.path.getmtime(os.path.join(folder, DB))
    except OSError:
        return None


def due(folder):
    """Treba obnoviť? Nie, keď je databáza čerstvá alebo ju práve stavia iné spustenie doplnku."""
    current = age(folder)
    if current is not None and current < MAX_AGE:
        return False
    try:
        return time.time() - os.path.getmtime(os.path.join(folder, DB + '.tmp')) > BUILDING_TTL
    except OSError:
        return True


def _unlink(path):
    try:
        os.remove(path)
    except OSError:
        pass


def remove(folder):
    for name in (DB, DB + '.tmp'):
        _unlink(os.path.join(folder, name))


def refresh(folder, abort=lambda: False):
    """Stiahne súbor, postaví novú databázu vedľa starej a vymení ich. Vráti počet titulov."""
    os.makedirs(folder, exist_ok=True)
    tmp = os.path.join(folder, DB + '.tmp')
    _unlink(tmp)
    body, count = b'', 0

    def rows():
        nonlocal count
        with gzip.open(io.BytesIO(body), 'rt', encoding='utf-8') as f:
            next(f)  # hlavička tconst, averageRating, numVotes
            for line in f:
                tconst, rating, votes = line.rstrip('\n').split('\t')
                count += 1
                if count % 100000 == 0 and abort():
                    raise Aborted()
                # hodnotenie ako celé číslo × 10, databáza je tak menšia
                yield int(tconst[2:]), round(float(rating) * 10), int(votes)

    db = sqlite3.connect(tmp)
    try:
        db.execute('PRAGMA journal_mode = OFF')
        db.execute('PRAGMA synchronous = OFF')
        # tabuľka vznikne pred sťahovaním – .tmp tak hneď hlási iným spusteniam, že sa už stavia
        db.execute('CREATE TABLE r (id INTEGER PRIMARY KEY, rating INTEGER, votes INTEGER)')
        status, body, _ = net.get(URL, timeout=60)
        if status != 200:
            raise IOError('datasets.imdbws.com vrátil HTTP %d' % status)
        with db:
            db.executemany('INSERT INTO r VALUES (?, ?, ?)', rows())
    except BaseException:
        db.close()
        _unlink(tmp)
        raise
    db.close()
    os.replace(tmp, os.path.join(folder, DB))
    return count
