# -*- coding: utf-8 -*-
"""Jednoduchá kľúč–hodnota cache v SQLite (addon_data/cache.db)."""

import json
import os
import sqlite3
import time

MISS = object()


class Cache:
    def __init__(self, folder):
        os.makedirs(folder, exist_ok=True)
        self.db = sqlite3.connect(os.path.join(folder, 'cache.db'), timeout=10)
        self.db.execute('CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT, t REAL)')

    def get(self, key, ttl):
        row = self.db.execute('SELECT v, t FROM kv WHERE k = ?', (key,)).fetchone()
        if row and time.time() - row[1] < ttl:
            return json.loads(row[0])
        return MISS

    def set_many(self, pairs):
        now = time.time()
        with self.db:
            self.db.executemany('INSERT OR REPLACE INTO kv VALUES (?, ?, ?)',
                                [(k, json.dumps(v, ensure_ascii=False), now) for k, v in pairs])

    def set(self, key, value):
        self.set_many([(key, value)])

    def clear(self, prefix=''):
        with self.db:
            self.db.execute('DELETE FROM kv WHERE k LIKE ?', (prefix + '%',))
        self.db.execute('VACUUM')
