# -*- coding: utf-8 -*-
"""Dáta zo sosac.to (JSON výstupy pôvodného doplnku plugin.video.sosac.ph).

Pôvodný kód: Libor Zoubek + jondas, GPL-2.0-or-later. Tu len prepísaný na čisté
dáta bez Kodi UI, aby sa dali vykresliť v štýle Stream Cinema.
"""

import json
import string
import unicodedata
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

from resources.lib import net
from resources.lib.cache import MISS

BASE = 'http://tv.sosac.to'
OUT = BASE + '/vystupy5981'
MOVIES_AZ = OUT + '/souboryaz.json'
MOVIES_GENRES = OUT + '/souboryzanry.json'
MOVIES_POPULAR = OUT + '/moviesmostpopular.json'
MOVIES_RECENT = OUT + '/moviesrecentlyadded.json'
TV_LETTER = OUT + '/tvpismena/'
TV_POPULAR = OUT + '/tvshowsmostpopular.json'
TV_RECENT = OUT + '/tvshowsrecentlyadded.json'
SEARCH = BASE + '/jsonsearchapi.php?q='

IMG_MOVIE = 'https://movies.sosac.tv/images/75x109/movie-'
IMG_SERIES = 'https://movies.sosac.tv/images/558x313/serial-'

TV_LETTERS = ['0-9'] + list(string.ascii_lowercase)

GENRES_SK = {
    'action': 'Akčný', 'adventure': 'Dobrodružný', 'animation': 'Animovaný', 'biography': 'Životopisný',
    'comedy': 'Komédia', 'crime': 'Krimi', 'krimi': 'Krimi', 'disaster': 'Katastrofický',
    'documentary': 'Dokumentárny', 'drama': 'Dráma', 'erotic': 'Erotický', 'experimental': 'Experimentálny',
    'fairytales': 'Rozprávka', 'family': 'Rodinný', 'fantasy': 'Fantasy', 'history': 'Historický',
    'horror': 'Horor', 'imax': 'IMAX', 'music': 'Hudobný', 'mystery': 'Mysteriózny',
    'psychological': 'Psychologický', 'publicistic': 'Publicistický', 'realitytv': 'Reality TV',
    'romance': 'Romantický', 'sci-fi': 'Sci-Fi', 'sport': 'Športový', 'talkshow': 'Talk show',
    'thriller': 'Thriller', 'war': 'Vojnový', 'western': 'Western',
}

# Zoznamy sa na sosac.to menia zriedka; novinky častejšie.
TTL_LIST = 6 * 3600
TTL_RECENT = 3600


class Sosac:
    def __init__(self, cache, czech_titles=True):
        self.cache = cache
        self.lang = 'cs' if czech_titles else 'en'

    @staticmethod
    def _fetch(url):
        status, body, _ = net.get(url, timeout=30)
        if status != 200:
            raise IOError('sosac.to vrátil HTTP %s pre %s' % (status, url))
        return json.loads(body)

    def _json(self, url, ttl=TTL_LIST):
        return self._json_many([url], ttl)[0]

    def _json_many(self, urls, ttl=TTL_LIST):
        """Chýbajúce súbory stiahne paralelne, do cache zapisuje len hlavné vlákno."""
        data = {u: self.cache.get('sosac:' + u, ttl) for u in urls}
        missing = [u for u, v in data.items() if v is MISS]
        if missing:
            with ThreadPoolExecutor(max_workers=8) as pool:
                fetched = list(pool.map(self._fetch, missing))
            self.cache.set_many([('sosac:' + u, v) for u, v in zip(missing, fetched)])
            data.update(zip(missing, fetched))
        return [data[u] for u in urls]

    def _name(self, names):
        return names.get(self.lang) or names.get('cs') or next(iter(names.values()), '')

    # --- filmy -------------------------------------------------------------

    def movie(self, v):
        imdb = v.get('m')
        return {
            'id': v.get('l') or '',
            'title': self._name(v['n']),
            'title_en': v['n'].get('en') or v['n'].get('cs'),
            'year': int(v['y']) if v.get('y') else 0,
            'rating': (v.get('r') or 0) * 2,
            'dub': list(dict.fromkeys(v.get('d') or [])),
            'subs': list(dict.fromkeys(v.get('s') or [])),
            'quality': (v.get('q') or '').lower(),
            'genres': [GENRES_SK.get(g, g.capitalize()) for g in (v.get('g') or []) if g != 'html5'],
            'csfd': v.get('c'),
            'imdb': 'tt' + imdb.zfill(7) if imdb else None,
            'poster': IMG_MOVIE + v['i'] if v.get('i') else None,
        }

    def movies(self, url):
        ttl = TTL_RECENT if url == MOVIES_RECENT else TTL_LIST
        return [self.movie(v) for v in self._json(url, ttl)]

    def search(self, query):
        return [self.movie(v) for v in self._json(SEARCH + urllib.parse.quote_plus(query), TTL_RECENT)]

    def movie_letters(self):
        return sorted(self._json(MOVIES_AZ).items())

    def movie_genres(self):
        return sorted(self._json(MOVIES_GENRES).items())

    # --- seriály -----------------------------------------------------------

    def tvshows(self, url):
        return [self._show(s) for s in self._json(url)]

    def tv_index(self):
        """Všetky seriály z A–Z podľa názvu bez diakritiky (české aj anglické názvy)."""
        index = {}
        for letter in self._json_many([self.tv_letter_url(l) for l in TV_LETTERS]):
            for s in letter:
                for name in s['n'].values():
                    index.setdefault(_fold(name), s)
        return index

    def find_show(self, keys, index):
        s = next((index[k] for k in keys if k in index), None)
        return self._show(s) if s else None

    def search_tv(self, query):
        """sosac.to nemá API na hľadanie seriálov – prehľadá všetky písmená A–Z."""
        words = _fold(query).split()
        found = {}
        for letter in self._json_many([self.tv_letter_url(l) for l in TV_LETTERS]):
            for s in letter:
                names = _fold(' '.join(s['n'].values()))
                if all(w in names for w in words):
                    found[s['l']] = self._show(s)
        q = _fold(query)
        return sorted(found.values(), key=lambda s: (not _fold(s['title']).startswith(q), s['title'].lower()))

    def _show(self, s):
        imdb = s.get('m')
        return {
            'url': s['l'],
            'title': self._name(s['n']),
            'title_en': s['n'].get('en') or s['n'].get('cs'),
            'year': int(s['y']) if s.get('y') else 0,
            'plot': s.get('p') or '',
            'rating': (s.get('r') or 0) * 2,
            'genres': [GENRES_SK.get(g, g.capitalize()) for g in (s.get('g') or [])],
            'csfd': s.get('c'),
            'imdb': 'tt' + imdb.zfill(7) if imdb else None,
            'landscape': IMG_SERIES + s['i'] if s.get('i') else None,
        }

    def tv_letter_url(self, letter):
        return TV_LETTER + letter + '.json'

    def episodes(self, url):
        """Vráti {séria: [epizódy zoradené podľa čísla]}."""
        seasons = {}
        for block in self._json(url):
            for season, eps in block.items():
                for number, e in eps.items():
                    seasons.setdefault(int(season), []).append({
                        'id': e.get('l') or '',
                        'season': int(season),
                        'episode': int(number),
                        'title': e.get('n') or '',
                        'thumb': BASE + e['i'] if e.get('i') else None,
                    })
        for eps in seasons.values():
            eps.sort(key=lambda e: e['episode'])
        return seasons

    def recent_episodes(self):
        result = []
        for e in self._json(TV_RECENT, TTL_RECENT):
            result.append({
                'id': e.get('l') or '',
                'show': self._name(e['t']),
                'show_keys': [_fold(n) for n in e['t'].values()],
                'season': int(e['s']),
                'episode': int(e['e']),
                'title': self._name(e['n']),
                'thumb': BASE + e['i'] if e.get('i') else None,
            })
        return result


def _fold(text):
    """Malé písmená bez diakritiky, aby „teoria“ našlo aj „Teorie“."""
    return ''.join(c for c in unicodedata.normalize('NFKD', text.lower()) if not unicodedata.combining(c))
