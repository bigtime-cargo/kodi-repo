# -*- coding: utf-8 -*-
"""HTTP pomocník: spoločné cookies (streamuj.tv ich vyžaduje) a GET bez presmerovania."""

import http.cookiejar
import urllib.error
import urllib.request

UA = 'Mozilla/5.0 (X11; Linux x86_64; rv:130.0) Gecko/20100101 Firefox/130.0'

COOKIES = http.cookiejar.CookieJar()


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(COOKIES))
_opener_noredirect = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(COOKIES), _NoRedirect())


def get(url, headers=None, timeout=20, follow=True, data=None):
    """Vráti (status, body bytes, hlavičky). HTTP chyby nevyhadzuje, len sieťové. S data= pošle POST."""
    h = {'User-Agent': UA}
    h.update(headers or {})
    opener = _opener if follow else _opener_noredirect
    try:
        with opener.open(urllib.request.Request(url, data=data, headers=h), timeout=timeout) as r:
            return r.status, r.read(), r.headers
    except urllib.error.HTTPError as e:
        body = e.read()
        e.close()
        return e.code, body, e.headers


def cookie_header():
    return '; '.join('%s=%s' % (c.name, c.value) for c in COOKIES)
