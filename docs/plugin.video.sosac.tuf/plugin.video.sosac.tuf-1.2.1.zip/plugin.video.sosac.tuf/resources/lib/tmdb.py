# -*- coding: utf-8 -*-
"""Metadáta z TMDB (popis, plagát, pozadie, hodnotenie) s cache v SQLite.

Hľadá sa podľa IMDb ID zo Sosáča (/find), bez neho podľa názvu a roku.
"""

import json
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

from resources.lib import net
from resources.lib.cache import MISS

API = 'https://api.themoviedb.org/3'
IMG = 'https://image.tmdb.org/t/p/'

TTL_FOUND = 30 * 86400
TTL_NOT_FOUND = 7 * 86400
TTL_SEASON = 3 * 86400
WORKERS = 8


class TmdbAuthError(Exception):
    pass


def _img(path, size):
    return IMG + size + path if path else None


class Tmdb:
    def __init__(self, key, cache, language='cs-CZ'):
        self.key = (key or '').strip()
        self.cache = cache
        self.language = language

    @property
    def enabled(self):
        return bool(self.key)

    def _get(self, path, **params):
        params['language'] = self.language
        headers = {'Accept': 'application/json'}
        # v4 „API Read Access Token“ je dlhý JWT, v3 „API Key“ má 32 znakov
        if len(self.key) > 40:
            headers['Authorization'] = 'Bearer ' + self.key
        else:
            params['api_key'] = self.key
        status, body, _ = net.get(API + path + '?' + urllib.parse.urlencode(params), headers=headers, timeout=15)
        if status == 401:
            raise TmdbAuthError('TMDB odmietol kľúč')
        if status != 200:
            return None
        return json.loads(body)

    def _parallel(self, keys, fetch, ttl_found=TTL_FOUND):
        """Pre každý kľúč vráti výsledok z cache alebo ho stiahne paralelne a uloží."""
        out, missing = {}, []
        for k in keys:
            v = self.cache.get(k, ttl_found)
            if v is MISS or (v == {} and self.cache.get(k, TTL_NOT_FOUND) is MISS):
                missing.append(k)
            else:
                out[k] = v
        if missing and self.enabled:
            with ThreadPoolExecutor(max_workers=WORKERS) as pool:
                fetched = list(pool.map(fetch, missing))
            # None = chyba siete, neukladať; {} = nenájdené, uložiť
            self.cache.set_many([(k, v) for k, v in zip(missing, fetched) if v is not None])
            out.update({k: v for k, v in zip(missing, fetched) if v is not None})
        return out

    # --- filmy a seriály -----------------------------------------------------

    @staticmethod
    def _meta(r, kind):
        return {
            'tmdb': r['id'],
            'title': r.get('title') or r.get('name'),
            'plot': r.get('overview') or '',
            'poster': _img(r.get('poster_path'), 'w500'),
            'fanart': _img(r.get('backdrop_path'), 'w1280'),
            'rating': r.get('vote_average') or 0,
            'votes': r.get('vote_count') or 0,
            'kind': kind,
        }

    def _lookup(self, kind, rec):
        try:
            if rec.get('imdb'):
                data = self._get('/find/' + rec['imdb'], external_source='imdb_id')
                if data is None:
                    return None
                hits = data.get('movie_results' if kind == 'movie' else 'tv_results') or []
                if hits:
                    return self._meta(hits[0], kind)
            query = rec.get('title_en') or rec.get('title')
            params = {'query': query}
            if rec.get('year'):
                params['year' if kind == 'movie' else 'first_air_date_year'] = rec['year']
            data = self._get('/search/' + kind, **params)
            if data is None:
                return None
            hits = data.get('results') or []
            return self._meta(hits[0], kind) if hits else {}
        except TmdbAuthError:
            raise
        except Exception:
            return None

    def _key(self, kind, rec):
        ident = rec.get('imdb') or '%s|%s' % (rec.get('title_en') or rec.get('title'), rec.get('year'))
        return 'tmdb:%s:%s:%s' % (self.language, kind, ident)

    def lookup_many(self, kind, recs):
        """kind = 'movie' alebo 'tv'. Vráti zoznam metadát v poradí recs ({} ak nič)."""
        keys = [self._key(kind, r) for r in recs]
        by_key = dict(zip(keys, recs))
        found = self._parallel(keys, lambda k: self._lookup(kind, by_key[k]))
        return [found.get(k) or {} for k in keys]

    # --- seriály: série a epizódy -------------------------------------------

    def _cached(self, key, ttl, fetch):
        v = self.cache.get(key, ttl)
        if v is MISS and self.enabled:
            v = fetch()
            if v is not None:
                self.cache.set(key, v)
        return v if v is not MISS and v is not None else {}

    def tv_seasons(self, tmdb_id):
        """{číslo série: {'poster', 'plot', 'name'}}"""
        def fetch():
            data = self._get('/tv/%s' % tmdb_id)
            if data is None:
                return None
            return {str(s['season_number']): {'name': s.get('name'), 'plot': s.get('overview') or '',
                                              'poster': _img(s.get('poster_path'), 'w500')}
                    for s in data.get('seasons') or []}
        return self._cached('tmdb:%s:tvs:%s' % (self.language, tmdb_id), TTL_SEASON, fetch)

    def _fetch_season(self, tmdb_id, season):
        try:
            data = self._get('/tv/%s/season/%s' % (tmdb_id, season))
        except TmdbAuthError:
            raise
        except Exception:
            return None
        if data is None:
            return None
        return {str(e['episode_number']): {'name': e.get('name'), 'plot': e.get('overview') or '',
                                           'thumb': _img(e.get('still_path'), 'w780'),
                                           'aired': e.get('air_date') or '',
                                           'runtime': e.get('runtime') or 0,
                                           'rating': e.get('vote_average') or 0}
                for e in data.get('episodes') or []}

    def _season_key(self, tmdb_id, season):
        return 'tmdb:%s:season:%s:%s' % (self.language, tmdb_id, season)

    def season_episodes(self, tmdb_id, season):
        """{číslo epizódy: {'name', 'plot', 'thumb', 'aired', 'runtime', 'rating'}}"""
        return self._cached(self._season_key(tmdb_id, season), TTL_SEASON,
                            lambda: self._fetch_season(tmdb_id, season))

    def season_episodes_many(self, pairs):
        """{(tmdb_id, séria): epizódy} pre viac sérií naraz, chýbajúce sa sťahujú paralelne."""
        keys = {self._season_key(t, s): (t, s) for t, s in pairs}
        found = self._parallel(list(keys), lambda k: self._fetch_season(*keys[k]), TTL_SEASON)
        return {keys[k]: v for k, v in found.items()}
