# -*- coding: utf-8 -*-
"""Smerovanie a vykresľovanie zoznamov v štýle Stream Cinema."""

import datetime
import json
import os
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import sosac, streamuj
from resources.lib.cache import MISS, Cache
from resources.lib.tmdb import Tmdb, TmdbAuthError

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
NAME = ADDON.getAddonInfo('name')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])

# Estuary: 50 Zoznam, 51 Plagát, 53 Posun, 54 Info stena, 55 Široký zoznam, 500 Stena
VIEW_MODES = [0, 51, 500, 54, 53, 55]
TMDB_LANGS = ['cs-CZ', 'sk-SK', 'en-US']
LANG_LABEL = {'cs': 'CZ', 'sk': 'SK', 'en': 'EN'}
AUDIO_LANGS = ['', 'cs', 'sk', 'en']
ROUTES = {'root', 'movies_menu', 'tv_menu', 'movie_genres', 'movie_letters', 'tv_letters', 'movies', 'tvshows',
          'seasons', 'episodes', 'recent_episodes', 'search_menu', 'search', 'search_delete', 'play', 'clear_cache',
          'movies_watching', 'tv_watching', 'watching_delete'}
# Údaje o položke uložené pri jej zobrazení, aby ich prehrávanie vedelo zapísať do histórie
SNAPSHOT_TTL = 10 * 365 * 86400
PREMIUM_TTL = 6 * 3600
PREMIUM_WARN_DAYS = 7
WATCHED_MAX = 300


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def setting_int(key):
    try:
        return ADDON.getSettingInt(key)
    except Exception:
        return 0


def setting_bool(key, default=True):
    # nové nastavenie Kodi pozná až po reštarte, dovtedy getSettingBool vyhodí výnimku
    try:
        return ADDON.getSettingBool(key)
    except Exception:
        return default


def url_for(**params):
    return BASE_URL + '?' + urllib.parse.urlencode(params)


def notify(msg, icon=xbmcgui.NOTIFICATION_INFO, ms=5000):
    xbmcgui.Dialog().notification(NAME, msg, icon, ms)


class Plugin:
    def __init__(self):
        self.cache = Cache(PROFILE)
        self.api = sosac.Sosac(self.cache, czech_titles=ADDON.getSettingBool('czech_titles'))
        lang = setting_int('tmdb_lang')
        self.tmdb = Tmdb(ADDON.getSettingString('tmdb_key'), self.cache,
                         TMDB_LANGS[lang] if lang < len(TMDB_LANGS) else TMDB_LANGS[0])
        self.page_size = max(10, setting_int('page_size') or 60)

    # --- pomocníci pre adresáre ---------------------------------------------

    def folder(self, label, icon, **params):
        li = xbmcgui.ListItem(label, offscreen=True)
        li.setArt({'icon': icon, 'thumb': icon})
        xbmcplugin.addDirectoryItem(HANDLE, url_for(**params), li, True)

    def end(self, content='', view=False, sort=None, cache=True):
        if content:
            xbmcplugin.setContent(HANDLE, content)
        for s in sort or [xbmcplugin.SORT_METHOD_UNSORTED]:
            xbmcplugin.addSortMethod(HANDLE, s)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)
        idx = setting_int('view_mode')
        mode = VIEW_MODES[idx] if idx < len(VIEW_MODES) else 0
        if view and mode:
            xbmc.executebuiltin('Container.SetViewMode(%d)' % mode)

    def tmdb_lookup(self, kind, recs):
        try:
            return self.tmdb.lookup_many(kind, recs)
        except TmdbAuthError:
            notify('TMDB kľúč je neplatný – skontroluj nastavenia', xbmcgui.NOTIFICATION_WARNING)
            self.tmdb.key = ''
            return [{} for _ in recs]

    def paginate(self, items, page):
        """Vráti položky aktuálnej strany a za ne pridá „Ďalšia strana“."""
        pages = max(1, (len(items) + self.page_size - 1) // self.page_size)
        start = (page - 1) * self.page_size
        chunk = items[start:start + self.page_size]
        return chunk, (page < pages and (page + 1, pages))

    def next_page(self, nxt, **params):
        if nxt:
            page, pages = nxt
            li = xbmcgui.ListItem('[B]Ďalšia strana[/B] (%d/%d)' % (page, pages), offscreen=True)
            li.setArt({'icon': 'DefaultFolder.png'})
            li.setProperty('SpecialSort', 'bottom')
            xbmcplugin.addDirectoryItem(HANDLE, url_for(page=page, **params), li, True)

    # --- menu ---------------------------------------------------------------

    def root(self):
        self.folder('Hľadať filmy', 'DefaultAddonsSearch.png', action='search_menu', kind='movie')
        self.folder('Hľadať seriály', 'DefaultAddonsSearch.png', action='search_menu', kind='tv')
        self.folder('Filmy', 'DefaultMovies.png', action='movies_menu')
        self.folder('Seriály', 'DefaultTVShows.png', action='tv_menu')
        li = xbmcgui.ListItem('Nastavenia', offscreen=True)
        li.setArt({'icon': 'DefaultAddonProgram.png'})
        xbmcplugin.addDirectoryItem(HANDLE, url_for(action='settings'), li, False)
        if not self.tmdb.enabled:
            notify('Bez TMDB kľúča nebudú plagáty ani popisy – doplň ho v nastaveniach')
        self.end()
        self.premium_notice()

    def premium_notice(self):
        """Raz za spustenie Kodi ukáže vpravo hore, koľko dní zostáva z premium na streamuj.tv."""
        user = ADDON.getSettingString('streamujtv_user')
        password = ADDON.getSettingString('streamujtv_pass')
        home = xbmcgui.Window(10000)
        if not (user and password and setting_bool('premium_notify')) \
                or home.getProperty(ADDON_ID + '.premium_shown'):
            return
        home.setProperty(ADDON_ID + '.premium_shown', '1')
        key = 'premium:' + user
        until = self.cache.get(key, PREMIUM_TTL)
        if until is MISS:
            try:
                dt = streamuj.premium_until(user, password)
            except Exception as e:
                log('Stav premium sa nepodarilo zistiť: %s' % e, xbmc.LOGWARNING)
                notify(str(e), xbmcgui.NOTIFICATION_WARNING)
                return
            until = dt.isoformat() if dt else ''
            self.cache.set(key, until)
        if not until:
            notify('Streamuj.tv: premium nie je aktívne', xbmcgui.NOTIFICATION_WARNING, 8000)
            return
        dt = datetime.datetime.fromisoformat(until)
        days = (dt.date() - datetime.date.today()).days
        date = dt.strftime('%d.%m.%Y')
        if days < 0:
            notify('Streamuj.tv: premium vypršalo %s' % date, xbmcgui.NOTIFICATION_ERROR, 10000)
        elif days == 0:
            notify('Streamuj.tv: premium vyprší dnes o %s' % dt.strftime('%H:%M'), xbmcgui.NOTIFICATION_WARNING, 10000)
        elif days <= PREMIUM_WARN_DAYS:
            unit = 'deň' if days == 1 else 'dni' if days < 5 else 'dní'
            notify('Streamuj.tv: premium vyprší o %d %s (%s)' % (days, unit, date),
                   xbmcgui.NOTIFICATION_WARNING, 10000)
        else:
            notify('Streamuj.tv: premium ešte %d dní (do %s)' % (days, date))

    def movies_menu(self):
        self.folder('Práve sledované', 'DefaultInProgressShows.png', action='movies_watching')
        self.folder('Novinky', 'DefaultRecentlyAddedMovies.png', action='movies', url=sosac.MOVIES_RECENT,
                    sort='recent')
        self.folder('Najpopulárnejšie', 'DefaultMusicTop100.png', action='movies', url=sosac.MOVIES_POPULAR)
        self.folder('Žánre', 'DefaultGenre.png', action='movie_genres')
        self.folder('A – Z', 'DefaultMovieTitle.png', action='movie_letters')
        self.end()

    def tv_menu(self):
        self.folder('Práve sledované', 'DefaultInProgressShows.png', action='tv_watching')
        self.folder('Nové epizódy', 'DefaultRecentlyAddedEpisodes.png', action='recent_episodes')
        self.folder('Najpopulárnejšie', 'DefaultMusicTop100.png', action='tvshows', url=sosac.TV_POPULAR)
        self.folder('A – Z', 'DefaultTVShowTitle.png', action='tv_letters')
        self.end()

    def movie_genres(self):
        for name, url in self.api.movie_genres():
            self.folder(name, 'DefaultGenre.png', action='movies', url=url)
        self.end()

    def movie_letters(self):
        for letter, url in self.api.movie_letters():
            self.folder(letter.upper(), 'DefaultFolder.png', action='movies', url=url)
        self.end()

    def tv_letters(self):
        for letter in sosac.TV_LETTERS:
            self.folder(letter.upper(), 'DefaultFolder.png', action='tvshows', url=self.api.tv_letter_url(letter))
        self.end()

    # --- filmy --------------------------------------------------------------

    def dub_filter(self, movies):
        mode = setting_int('dub_filter')
        if mode == 1:
            return [m for m in movies if {'cs', 'sk'} & set(m['dub'])]
        if mode == 2:
            return [m for m in movies if {'cs', 'sk'} & (set(m['dub']) | set(m['subs']))]
        return movies

    @staticmethod
    def lang_suffix(m):
        dub = [LANG_LABEL.get(d, d.upper()) for d in m['dub']]
        text = ', '.join(dub)
        if m['subs']:
            text += (' + ' if text else '') + 'tit. ' + ', '.join(LANG_LABEL.get(s, s.upper()) for s in m['subs'])
        return text

    def movie_item(self, m, meta):
        suffix = self.lang_suffix(m)
        label = m['title'] + (' - ' + suffix if suffix else '')
        li = xbmcgui.ListItem(label, offscreen=True)
        tag = li.getVideoInfoTag()
        tag.setMediaType('movie')
        tag.setTitle(label)
        tag.setOriginalTitle(m['title_en'] or m['title'])
        if m['year']:
            tag.setYear(m['year'])
        tag.setGenres(m['genres'])
        tag.setPlot(meta.get('plot') or ', '.join(m['genres']))
        if meta.get('rating'):
            tag.setRating(float(meta['rating']), int(meta.get('votes') or 0), 'tmdb', True)
        elif m['rating']:
            tag.setRating(float(m['rating']), 0, 'sosac', True)
        ids = {k: str(v) for k, v in (('imdb', m['imdb']), ('tmdb', meta.get('tmdb')), ('csfd', m['csfd'])) if v}
        if ids:
            tag.setUniqueIDs(ids, 'imdb' if 'imdb' in ids else next(iter(ids)))
        if m['imdb']:
            tag.setIMDBNumber(m['imdb'])
        width, height = {'uhdhdr': (3840, 2160), 'fhd': (1920, 1080), 'hd': (1280, 720)}.get(m['quality'], (720, 404))
        tag.addVideoStream(xbmc.VideoStreamDetail(width=width, height=height, codec='h264'))
        for d in m['dub']:
            tag.addAudioStream(xbmc.AudioStreamDetail(channels=2, codec='aac', language=d))
        for s in m['subs']:
            tag.addSubtitleStream(xbmc.SubtitleStreamDetail(language=s))
        poster = meta.get('poster') or m['poster']
        art = {'poster': poster, 'thumb': poster, 'icon': poster}
        if meta.get('fanart'):
            art['fanart'] = meta['fanart']
            art['landscape'] = meta['fanart']
        li.setArt(art)
        li.setProperty('IsPlayable', 'true')
        return url_for(action='play', id=m['id']), li, False

    def movies(self, url, page=1, sort=''):
        items = self.dub_filter(self.api.movies(url))
        self.show_movies(items, page, sort, action='movies', url=url, sort=sort)

    def show_movies(self, items, page, order, **params):
        if order == 'recent':
            order = setting_int('order_recent')
            if order == 1:
                items.sort(key=lambda m: m['title'].lower())
            elif order == 2:
                items.sort(key=lambda m: m['year'], reverse=True)
        items = [m for m in items if m['id']]
        chunk, nxt = self.paginate(items, page)
        metas = self.tmdb_lookup('movie', chunk)
        self.cache.set_many([('item:' + m['id'], {'kind': 'movie', 'm': m, 'meta': meta})
                             for m, meta in zip(chunk, metas)])
        xbmcplugin.addDirectoryItems(HANDLE, [self.movie_item(m, meta) for m, meta in zip(chunk, metas)], len(chunk))
        self.next_page(nxt, **params)
        self.end('movies', view=True, sort=[xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL,
                                            xbmcplugin.SORT_METHOD_VIDEO_YEAR, xbmcplugin.SORT_METHOD_VIDEO_RATING])

    # --- seriály ------------------------------------------------------------

    def tvshows(self, url, page=1):
        self.show_tvshows(self.api.tvshows(url), page, action='tvshows', url=url)

    def show_tvshows(self, items, page, **params):
        chunk, nxt = self.paginate(items, page)
        metas = self.tmdb_lookup('tv', chunk)
        self.cache.set_many([('show:' + s['url'], {'s': s, 'meta': meta}) for s, meta in zip(chunk, metas)])
        entries = []
        for s, meta in zip(chunk, metas):
            li = self.show_listitem(s, meta)
            entries.append((url_for(action='seasons', url=s['url'], tmdb=meta.get('tmdb') or '',
                                    show=s['title']), li, True))
        xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
        self.next_page(nxt, **params)
        self.end('tvshows', view=True, sort=[xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL,
                                             xbmcplugin.SORT_METHOD_VIDEO_YEAR])

    @staticmethod
    def show_listitem(s, meta, label=None):
        label = label or s['title']
        li = xbmcgui.ListItem(label, offscreen=True)
        tag = li.getVideoInfoTag()
        tag.setMediaType('tvshow')
        tag.setTitle(label)
        tag.setTvShowTitle(s['title'])
        tag.setOriginalTitle(s['title_en'] or s['title'])
        if s['year']:
            tag.setYear(s['year'])
        tag.setGenres(s['genres'])
        tag.setPlot(s['plot'] or meta.get('plot') or '')
        if meta.get('rating'):
            tag.setRating(float(meta['rating']), int(meta.get('votes') or 0), 'tmdb', True)
        elif s['rating']:
            tag.setRating(float(s['rating']), 0, 'sosac', True)
        if s['imdb']:
            tag.setIMDBNumber(s['imdb'])
        poster = meta.get('poster') or s['landscape']
        fanart = meta.get('fanart') or s['landscape']
        li.setArt({'poster': poster, 'thumb': poster, 'icon': poster, 'fanart': fanart,
                   'landscape': s['landscape'] or fanart})
        return li

    def seasons(self, url, tmdb='', show=''):
        seasons = self.api.episodes(url)
        tmdb_seasons = self.tmdb.tv_seasons(tmdb) if tmdb else {}
        if len(seasons) == 1:
            n = next(iter(seasons))
            return self.episodes(url, n, tmdb, show)
        entries = []
        for n in sorted(seasons):
            ts = tmdb_seasons.get(str(n), {})
            label = '%d. séria' % n if n else 'Špeciály'
            li = xbmcgui.ListItem(label, offscreen=True)
            tag = li.getVideoInfoTag()
            tag.setMediaType('season')
            tag.setTitle(label)
            tag.setTvShowTitle(show)
            tag.setSeason(n)
            tag.setPlot(ts.get('plot') or '%d epizód' % len(seasons[n]))
            if ts.get('poster'):
                li.setArt({'poster': ts['poster'], 'thumb': ts['poster']})
            entries.append((url_for(action='episodes', url=url, season=n, tmdb=tmdb, show=show), li, True))
        xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
        self.end('seasons', view=True)

    def episodes(self, url, season, tmdb='', show=''):
        season = int(season)
        eps = self.api.episodes(url).get(season, [])
        tmdb_eps = self.tmdb.season_episodes(tmdb, season) if tmdb else {}
        entries, snaps = [], []
        for e in eps:
            if not e['id']:
                continue
            te = tmdb_eps.get(str(e['episode']), {})
            name = te.get('name') or e['title']
            snaps.append(('item:' + e['id'], {'kind': 'episode', 'show_url': url, 'show': show, 'tmdb': tmdb,
                                              'season': season, 'episode': e['episode'], 'name': name}))
            label = '%dx%02d %s' % (season, e['episode'], name)
            li = xbmcgui.ListItem(label, offscreen=True)
            tag = li.getVideoInfoTag()
            tag.setMediaType('episode')
            tag.setTitle(name)
            tag.setTvShowTitle(show)
            tag.setSeason(season)
            tag.setEpisode(e['episode'])
            tag.setPlot(te.get('plot') or '')
            if te.get('aired'):
                tag.setFirstAired(te['aired'])
            if te.get('runtime'):
                tag.setDuration(int(te['runtime']) * 60)
            if te.get('rating'):
                tag.setRating(float(te['rating']), 0, 'tmdb', True)
            thumb = te.get('thumb') or e['thumb']
            li.setArt({'thumb': thumb, 'icon': thumb})
            li.setProperty('IsPlayable', 'true')
            entries.append((url_for(action='play', id=e['id']), li, False))
        self.cache.set_many(snaps)
        xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
        self.end('episodes', view=False, sort=[xbmcplugin.SORT_METHOD_EPISODE, xbmcplugin.SORT_METHOD_UNSORTED])

    def recent_episodes(self):
        eps = [e for e in self.api.recent_episodes() if e['id']]
        # Novinky nemajú odkaz na seriál – dohľadá sa podľa názvu v zozname A–Z
        index = self.api.tv_index()
        for e in eps:
            e['show_rec'] = self.api.find_show(e['show_keys'], index)
        shows = list({e['show_rec']['url']: e['show_rec'] for e in eps if e['show_rec']}.values())
        metas = dict(zip([s['url'] for s in shows], self.tmdb_lookup('tv', shows)))
        pairs = {(metas[e['show_rec']['url']]['tmdb'], e['season'])
                 for e in eps if e['show_rec'] and metas[e['show_rec']['url']].get('tmdb')}
        try:
            seasons = self.tmdb.season_episodes_many(pairs)
        except TmdbAuthError:
            seasons = {}

        self.cache.set_many([('show:' + s['url'], {'s': s, 'meta': metas[s['url']]}) for s in shows])
        entries, snaps = [], []
        for e in eps:
            show = e['show_rec'] or {}
            meta = metas.get(show.get('url'), {})
            te = seasons.get((meta.get('tmdb'), e['season']), {}).get(str(e['episode']), {})
            name = te.get('name') or e['title']
            if show:
                snaps.append(('item:' + e['id'], {'kind': 'episode', 'show_url': show['url'], 'show': e['show'],
                                                  'tmdb': meta.get('tmdb') or '', 'season': e['season'],
                                                  'episode': e['episode'], 'name': name}))
            # Názov seriálu musí byť aj v titulku – Estuary pri epizódach zobrazuje titulok, nie label
            label = '%s – %dx%02d %s' % (e['show'], e['season'], e['episode'], name)
            li = xbmcgui.ListItem(label, offscreen=True)
            tag = li.getVideoInfoTag()
            tag.setMediaType('episode')
            tag.setTitle(label)
            tag.setTvShowTitle(e['show'])
            tag.setSeason(e['season'])
            tag.setEpisode(e['episode'])
            tag.setPlot(te.get('plot') or show.get('plot') or meta.get('plot') or '')
            if te.get('aired'):
                tag.setFirstAired(te['aired'])
            if te.get('runtime'):
                tag.setDuration(int(te['runtime']) * 60)
            if show.get('genres'):
                tag.setGenres(show['genres'])
            thumb = te.get('thumb') or e['thumb']
            poster = meta.get('poster') or show.get('landscape')
            fanart = meta.get('fanart') or show.get('landscape')
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': poster, 'fanart': fanart,
                       'tvshow.poster': poster, 'tvshow.fanart': fanart})
            li.setProperty('IsPlayable', 'true')
            if show:
                li.addContextMenuItems([('Prejsť na seriál', 'Container.Update(%s)' % url_for(
                    action='seasons', url=show['url'], tmdb=meta.get('tmdb') or '', show=e['show']))])
            entries.append((url_for(action='play', id=e['id']), li, False))
        self.cache.set_many(snaps)
        xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
        self.end('episodes')

    # --- práve sledované ----------------------------------------------------

    @staticmethod
    def _watched_path():
        return os.path.join(PROFILE, 'watched.json')

    def _watched(self):
        try:
            with open(self._watched_path(), encoding='utf-8') as f:
                return json.load(f)
        except (OSError, ValueError):
            return []

    def _save_watched(self, items):
        os.makedirs(PROFILE, exist_ok=True)
        with open(self._watched_path(), 'w', encoding='utf-8') as f:
            json.dump(items[:WATCHED_MAX], f, ensure_ascii=False)

    def remember(self, id):
        """Zapíše prehrávanú položku na začiatok histórie (vlastný súbor, „Vymazať cache“ ho nezmaže)."""
        snap = self.cache.get('item:' + id, SNAPSHOT_TTL)
        if snap is MISS:
            return
        entry = dict(snap, id=id, ts=time.time())
        if snap['kind'] == 'episode':
            show = self.cache.get('show:' + snap['show_url'], SNAPSHOT_TTL)
            if show is not MISS:
                entry['show_snap'] = show
        self._save_watched([entry] + [h for h in self._watched() if h['id'] != id])

    @staticmethod
    def delete_menu(**params):
        return ('Odstrániť z práve sledovaných', 'RunPlugin(%s)' % url_for(action='watching_delete', **params))

    def movies_watching(self):
        entries = []
        for h in self._watched():
            if h['kind'] != 'movie':
                continue
            url, li, folder = self.movie_item(h['m'], h['meta'])
            li.addContextMenuItems([self.delete_menu(id=h['id'])])
            entries.append((url, li, folder))
        xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
        self.end('movies', view=True, cache=False)

    def tv_watching(self):
        entries, seen = [], set()
        for h in self._watched():
            if h['kind'] != 'episode' or h['show_url'] in seen:
                continue
            seen.add(h['show_url'])
            snap = h.get('show_snap') or {'s': {'title': h['show'], 'title_en': '', 'year': 0, 'plot': '',
                                                'rating': 0, 'genres': [], 'imdb': None, 'landscape': None},
                                          'meta': {}}
            label = '%s – naposledy %dx%02d' % (h['show'], h['season'], h['episode'])
            li = self.show_listitem(snap['s'], snap['meta'], label)
            li.addContextMenuItems([
                ('Všetky série', 'Container.Update(%s)' % url_for(action='seasons', url=h['show_url'],
                                                                  tmdb=h['tmdb'], show=h['show'])),
                self.delete_menu(show_url=h['show_url'])])
            # otvorí rovno sériu, v ktorej sa naposledy pozeralo
            entries.append((url_for(action='episodes', url=h['show_url'], season=h['season'], tmdb=h['tmdb'],
                                    show=h['show']), li, True))
        xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
        self.end('tvshows', view=True, cache=False)

    def watching_delete(self, id='', show_url=''):
        self._save_watched([h for h in self._watched()
                            if not (id and h['id'] == id) and not (show_url and h.get('show_url') == show_url)])
        xbmc.executebuiltin('Container.Refresh')

    # --- vyhľadávanie -------------------------------------------------------

    @staticmethod
    def _history_path(kind):
        return os.path.join(PROFILE, 'search_tv.json' if kind == 'tv' else 'search.json')

    def _history(self, kind):
        try:
            with open(self._history_path(kind), encoding='utf-8') as f:
                return json.load(f)
        except (OSError, ValueError):
            return []

    def _save_history(self, kind, items):
        os.makedirs(PROFILE, exist_ok=True)
        with open(self._history_path(kind), 'w', encoding='utf-8') as f:
            json.dump(items[:max(1, setting_int('keep_searches') or 20)], f, ensure_ascii=False)

    def search_menu(self, kind='movie'):
        self.folder('[B]Nové hľadanie[/B]', 'DefaultAddonsSearch.png', action='search', kind=kind)
        for q in self._history(kind):
            li = xbmcgui.ListItem(q, offscreen=True)
            li.setArt({'icon': 'DefaultAddonsSearch.png'})
            li.addContextMenuItems([('Odstrániť z histórie',
                                     'RunPlugin(%s)' % url_for(action='search_delete', kind=kind, q=q))])
            xbmcplugin.addDirectoryItem(HANDLE, url_for(action='search', kind=kind, q=q), li, True)
        self.end(cache=False)

    def search(self, q='', page=1, kind='movie'):
        if not q:
            q = xbmcgui.Dialog().input('Hľadať seriál' if kind == 'tv' else 'Hľadať film')
            if not q:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return
        q = q.strip()
        if len(q) < 3:
            notify('Zadaj aspoň 3 znaky')
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        history = [h for h in self._history(kind) if h.lower() != q.lower()]
        self._save_history(kind, [q] + history)
        if kind == 'tv':
            self.show_tvshows(self.api.search_tv(q), page, action='search', kind=kind, q=q)
        else:
            self.show_movies(self.api.search(q), page, '', action='search', kind=kind, q=q)

    def search_delete(self, q, kind='movie'):
        self._save_history(kind, [h for h in self._history(kind) if h != q])
        xbmc.executebuiltin('Container.Refresh')

    # --- prehrávanie --------------------------------------------------------

    def choose_stream(self, streams):
        # 1. jazyk, ak chýba tak 2. jazyk, inak všetky streamy
        cands = []
        for key in ('audio_lang1', 'audio_lang2'):
            idx = setting_int(key)
            lang = AUDIO_LANGS[idx] if idx < len(AUDIO_LANGS) else ''
            cands = cands or [s for s in streams if lang and s['lang'] == lang]
        cands = cands or streams
        cands.sort(key=lambda s: streamuj.QUALITY_RANK.get(s['quality'], 0), reverse=True)
        quality = setting_int('quality')
        if len(cands) == 1 or quality == 1:
            return cands[0]
        if quality == 2:
            return cands[-1]
        labels = ['%s · %s%s' % (s['quality'], s['lang_name'], ' + titulky' if s['subs'] else '') for s in cands]
        idx = xbmcgui.Dialog().select('Vyber stream', labels)
        return cands[idx] if idx >= 0 else None

    def play(self, id):
        try:
            stream = self.choose_stream(streamuj.streams(id))
            if not stream:
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return
            url = streamuj.final_url(stream, ADDON.getSettingString('streamujtv_user'),
                                     ADDON.getSettingString('streamujtv_pass'),
                                     str(setting_int('streamujtv_location')))
        except Exception as e:
            log('Prehrávanie %s zlyhalo: %s' % (id, e), xbmc.LOGERROR)
            notify(str(e), xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        li = xbmcgui.ListItem(path=url, offscreen=True)
        if stream['subs'] and ADDON.getSettingBool('subs'):
            subs_dir = os.path.join(PROFILE, 'subs')
            os.makedirs(subs_dir, exist_ok=True)
            path = os.path.join(subs_dir, '%s.srt' % id)
            if streamuj.download_subs(stream['subs'], path):
                li.setSubtitles([path])
        log('Prehrávam %s (%s, %s)' % (id, stream['quality'], stream['lang']))
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
        self.remember(id)

    # --- ostatné ------------------------------------------------------------

    def clear_cache(self):
        self.cache.clear()
        notify('Cache vymazaná')

    def run(self, params):
        action = params.pop('action', 'root')
        if 'page' in params:
            params['page'] = int(params['page'])
        if action == 'settings':
            ADDON.openSettings()
            return
        handler = getattr(self, action, None) if action in ROUTES else None
        if handler is None:
            log('Neznáma akcia %s' % action, xbmc.LOGWARNING)
            return
        try:
            handler(**params)
        except IOError as e:
            log('Chyba siete: %s' % e, xbmc.LOGERROR)
            notify('sosac.to neodpovedá: %s' % e, xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def run():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    log('Spúšťam %s' % params, xbmc.LOGDEBUG)
    Plugin().run(params)
