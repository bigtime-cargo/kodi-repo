# -*- coding: utf-8 -*-
"""Metadáta z TMDB (popis, plagát, pozadie, hodnotenie) s cache v SQLite.

Hľadá sa podľa IMDb ID zo Sosáča (/find), bez neho podľa názvu a roku.
Keď popis vo zvolenom jazyku chýba, doplní sa z ďalšieho jazyka v poradí FALLBACK.
"""

import http.client
import json
import re
import threading
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, wait

from resources.lib import net
from resources.lib.cache import MISS

API = 'https://api.themoviedb.org/3'
IMG = 'https://image.tmdb.org/t/p/'

TTL_FOUND = 30 * 86400
TTL_NOT_FOUND = 7 * 86400
TTL_SEASON = 3 * 86400
WORKERS = 8
# najdlhšie, čo sa vo výpise čaká na doplnenie metadát; čo nestihne, sa ukáže bez nich
LOOKUP_DEADLINE = 20
# 2 = cache so záložným popisom; staré záznamy bez neho sa tak stiahnu nanovo
KEY_PREFIX = 'tmdb2'
# názov, ktorý TMDB dá epizóde bez prekladu
GENERIC_NAME = re.compile(r'^(Epizóda|Epizoda|Episode) \d+$')
FALLBACK = {'sk-SK': ['cs-CZ', 'en-US'], 'cs-CZ': ['sk-SK', 'en-US'], 'en-US': []}


class TmdbAuthError(Exception):
    pass


class TmdbDown(Exception):
    """Sieť k TMDB nefunguje (istič je vypnutý) – ďalšie volania sa v tomto behu nerobia."""


def _img(path, size):
    return IMG + size + path if path else None


class Tmdb:
    def __init__(self, key, cache, language='cs-CZ'):
        self.key = (key or '').strip()
        self.cache = cache
        self.language = language
        self.fallbacks = FALLBACK.get(language, ['en-US'])
        # istič: po prvej sieťovej chybe v tomto behu pluginu sa ďalšie volania hneď vzdajú
        # (zamrznutá sieť inak znamená 15 s čakania na každú položku zoznamu)
        self._down = threading.Event()

    @property
    def enabled(self):
        return bool(self.key)

    @property
    def down(self):
        return self._down.is_set()

    def _get(self, path, language=None, **params):
        if self._down.is_set():
            raise TmdbDown('TMDB je nedostupné')
        params['language'] = language or self.language
        headers = {'Accept': 'application/json'}
        # v4 „API Read Access Token“ je dlhý JWT, v3 „API Key“ má 32 znakov
        if len(self.key) > 40:
            headers['Authorization'] = 'Bearer ' + self.key
        else:
            params['api_key'] = self.key
        try:
            status, body, _ = net.get(API + path + '?' + urllib.parse.urlencode(params), headers=headers, timeout=15)
        except (OSError, http.client.HTTPException) as e:  # URLError a timeout sú podtriedy OSError
            self._down.set()
            raise TmdbDown('TMDB neodpovedá: %s' % e)
        if status == 401:
            raise TmdbAuthError('TMDB odmietol kľúč')
        if status != 200:
            return None
        return json.loads(body)

    def _parallel(self, keys, fetch, ttl_found=TTL_FOUND):
        """Pre každý kľúč vráti výsledok z cache alebo ho stiahne paralelne a uloží."""
        out, missing = {}, []
        for k in keys:
            v = self.cache.get(k, ttl_found)
            if v is MISS or (v == {} and self.cache.get(k, TTL_NOT_FOUND) is MISS):
                missing.append(k)
            else:
                out[k] = v
        if missing and self.enabled:
            # bez `with`: jeho koniec by počkal na zaseknuté vlákna a časový limit by nič nezmenil
            pool = ThreadPoolExecutor(max_workers=WORKERS)
            futures = {k: pool.submit(fetch, k) for k in missing}
            done, pending = wait(futures.values(), timeout=LOOKUP_DEADLINE)
            if pending:
                # nestihnuté položky sa ukážu bez metadát, zvyšok radu sa už nespúšťa
                self._down.set()
            pool.shutdown(wait=False, cancel_futures=True)
            fetched = {}
            for k, f in futures.items():
                if f in done:
                    try:
                        fetched[k] = f.result()
                    except TmdbAuthError:
                        raise
                    except Exception:
                        fetched[k] = None
            # None = chyba siete alebo nestihnuté, neukladať (ďalšie otvorenie to skúsi znova); {} = nenájdené, uložiť
            good = [(k, v) for k, v in fetched.items() if v is not None]
            self.cache.set_many(good)
            out.update(good)
        return out

    # --- filmy a seriály -----------------------------------------------------

    @staticmethod
    def _meta(r, kind):
        return {
            'tmdb': r['id'],
            'title': r.get('title') or r.get('name'),
            'plot': r.get('overview') or '',
            'poster': _img(r.get('poster_path'), 'w500'),
            'fanart': _img(r.get('backdrop_path'), 'w1280'),
            'rating': r.get('vote_average') or 0,
            'votes': r.get('vote_count') or 0,
            'kind': kind,
        }

    def _fill_plot(self, kind, meta):
        """Chýbajúci popis doplní z prekladov TMDB – jedna požiadavka vráti všetky jazyky."""
        if meta['plot'] or not self.fallbacks:
            return meta
        try:
            data = self._get('/%s/%s/translations' % (kind, meta['tmdb'])) or {}
        except TmdbAuthError:
            raise
        except Exception:
            if self._down.is_set():
                raise  # sieť nejde: výsledok bez popisu sa nesmie uložiť na 30 dní
            return meta
        plots = {}
        for t in data.get('translations') or []:
            overview = (t.get('data') or {}).get('overview')
            if overview:
                plots.setdefault(t.get('iso_639_1'), overview)
        for lang in self.fallbacks:
            if plots.get(lang[:2]):
                # plot_fallback: plugin potom uprednostní vlastný (český) popis Sosáča
                meta.update(plot=plots[lang[:2]], plot_fallback=True)
                break
        return meta

    def _lookup(self, kind, rec):
        try:
            if rec.get('imdb'):
                data = self._get('/find/' + rec['imdb'], external_source='imdb_id')
                if data is None:
                    return None
                hits = data.get('movie_results' if kind == 'movie' else 'tv_results') or []
                if hits:
                    return self._fill_plot(kind, self._meta(hits[0], kind))
            query = rec.get('title_en') or rec.get('title')
            params = {'query': query}
            if rec.get('year'):
                params['year' if kind == 'movie' else 'first_air_date_year'] = rec['year']
            data = self._get('/search/' + kind, **params)
            if data is None:
                return None
            hits = data.get('results') or []
            return self._fill_plot(kind, self._meta(hits[0], kind)) if hits else {}
        except TmdbAuthError:
            raise
        except Exception:
            return None

    def _key(self, kind, rec):
        ident = rec.get('imdb') or '%s|%s' % (rec.get('title_en') or rec.get('title'), rec.get('year'))
        return '%s:%s:%s:%s' % (KEY_PREFIX, self.language, kind, ident)

    def lookup_many(self, kind, recs):
        """kind = 'movie' alebo 'tv'. Vráti zoznam metadát v poradí recs ({} ak nič)."""
        keys = [self._key(kind, r) for r in recs]
        by_key = dict(zip(keys, recs))
        found = self._parallel(keys, lambda k: self._lookup(kind, by_key[k]))
        return [found.get(k) or {} for k in keys]

    # --- seriály: série a epizódy -------------------------------------------

    def _cached(self, key, ttl, fetch):
        v = self.cache.get(key, ttl)
        if v is MISS and self.enabled:
            v = fetch()
            if v is not None:
                self.cache.set(key, v)
        return v if v is not MISS and v is not None else {}

    def _with_fallback(self, fetch):
        """fetch(jazyk) → {číslo: {'plot', 'name', …}}; chýbajúce popisy a názvy typu „Epizóda 3“
        doplní z ďalších jazykov."""
        items = fetch(None)
        generic = lambda v: GENERIC_NAME.match(v.get('name') or '')
        for lang in self.fallbacks:
            missing = [k for k, v in (items or {}).items() if not v['plot'] or generic(v)]
            if not missing:
                break
            other = fetch(lang) or {}
            for k in missing:
                o = other.get(k, {})
                if not items[k]['plot']:
                    items[k]['plot'] = o.get('plot') or ''
                if generic(items[k]) and o.get('name') and not generic(o):
                    items[k]['name'] = o['name']
        return items

    def tv_seasons(self, tmdb_id):
        """{číslo série: {'poster', 'plot', 'name'}}"""
        def fetch(language):
            try:
                data = self._get('/tv/%s' % tmdb_id, language)
            except TmdbAuthError:
                raise
            except Exception:
                return None
            if data is None:
                return None
            return {str(s['season_number']): {'name': s.get('name'), 'plot': s.get('overview') or '',
                                              'poster': _img(s.get('poster_path'), 'w500')}
                    for s in data.get('seasons') or []}
        return self._cached('%s:%s:tvs:%s' % (KEY_PREFIX, self.language, tmdb_id), TTL_SEASON,
                            lambda: self._with_fallback(fetch))

    def _fetch_season(self, tmdb_id, season):
        def fetch(language):
            try:
                data = self._get('/tv/%s/season/%s' % (tmdb_id, season), language)
            except TmdbAuthError:
                raise
            except Exception:
                return None
            if data is None:
                return None
            return {str(e['episode_number']): {'name': e.get('name'), 'plot': e.get('overview') or '',
                                               'thumb': _img(e.get('still_path'), 'w780'),
                                               'aired': e.get('air_date') or '',
                                               'runtime': e.get('runtime') or 0,
                                               'rating': e.get('vote_average') or 0}
                    for e in data.get('episodes') or []}
        return self._with_fallback(fetch)

    def _season_key(self, tmdb_id, season):
        return '%s:%s:season:%s:%s' % (KEY_PREFIX, self.language, tmdb_id, season)

    def season_episodes(self, tmdb_id, season):
        """{číslo epizódy: {'name', 'plot', 'thumb', 'aired', 'runtime', 'rating'}}"""
        return self._cached(self._season_key(tmdb_id, season), TTL_SEASON,
                            lambda: self._fetch_season(tmdb_id, season))

    def season_episodes_many(self, pairs):
        """{(tmdb_id, séria): epizódy} pre viac sérií naraz, chýbajúce sa sťahujú paralelne."""
        keys = {self._season_key(t, s): (t, s) for t, s in pairs}
        found = self._parallel(list(keys), lambda k: self._fetch_season(*keys[k]), TTL_SEASON)
        return {keys[k]: v for k, v in found.items()}
